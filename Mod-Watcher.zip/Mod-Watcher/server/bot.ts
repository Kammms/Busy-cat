import { Client, GatewayIntentBits, Partials, Collection, EmbedBuilder, TextChannel } from 'discord.js';
import { storage } from './storage';
import { SETTINGS_KEYS } from '@shared/schema';

// Minimal Invite interface for caching
interface CachedInvite {
  code: string;
  uses: number;
  inviterId: string | null;
}

export class DiscordBot {
  private client: Client;
  private inviteCache: Collection<string, Collection<string, CachedInvite>> = new Collection();
  private isReady: boolean = false;

  constructor() {
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildInvites,
      ],
      partials: [Partials.Message, Partials.Channel, Partials.GuildMember],
    });

    this.setupListeners();
  }

  private setupListeners() {
    this.client.once('ready', async () => {
      console.log(`Logged in as ${this.client.user?.tag}!`);
      this.isReady = true;
      await this.refreshInviteCache();
    });

    this.client.on('messageCreate', async (message) => {
      if (message.author.bot || !message.guild) return;

      const trackedChannelId = await storage.getSetting(SETTINGS_KEYS.TRACKED_CHANNEL_ID);
      const modRoleId = await storage.getSetting(SETTINGS_KEYS.MODERATOR_ROLE_ID);

      if (!trackedChannelId || !modRoleId) return;
      if (message.channelId !== trackedChannelId) return;

      // Check if user has mod role
      const member = message.member;
      if (!member?.roles.cache.has(modRoleId)) return;

      // Update moderator stats
      let moderator = await storage.getModeratorByDiscordId(message.author.id);
      
      if (!moderator) {
        moderator = await storage.createModerator({
          discordId: message.author.id,
          username: message.author.username,
          avatar: message.author.avatar,
          isIgnored: false,
          manualPoints: 0,
        });
      }

      if (moderator.isIgnored) return;

      // Update username/avatar if changed
      const updates: any = { messageCount: moderator.messageCount + 1 };
      if (moderator.username !== message.author.username) updates.username = message.author.username;
      if (moderator.avatar !== message.author.avatar) updates.avatar = message.author.avatar;

      await storage.updateModerator(moderator.id, updates);
    });

    this.client.on('guildMemberAdd', async (member) => {
      const guild = member.guild;
      const cachedInvites = this.inviteCache.get(guild.id);
      
      // Fetch new invites
      const newInvites = await guild.invites.fetch().catch(() => new Collection());
      
      // Update cache and find used invite
      const usedInvite = newInvites.find(inv => {
        const cached = cachedInvites?.get(inv.code);
        return cached ? (inv.uses || 0) > cached.uses : false;
      });

      if (usedInvite && usedInvite.inviter) {
        const modRoleId = await storage.getSetting(SETTINGS_KEYS.MODERATOR_ROLE_ID);
        // Only count if inviter is a moderator (we need to fetch the member to check roles)
        try {
          const inviterMember = await guild.members.fetch(usedInvite.inviter.id);
          
          if (modRoleId && inviterMember.roles.cache.has(modRoleId)) {
             let moderator = await storage.getModeratorByDiscordId(usedInvite.inviter.id);
             
             if (moderator && !moderator.isIgnored) {
               await storage.updateModerator(moderator.id, {
                 inviteCount: moderator.inviteCount + 1
               });
             }
          }
        } catch (e) {
          console.error("Error fetching inviter member:", e);
        }
      }

      // Refresh cache for this guild
      if (cachedInvites) {
        this.inviteCache.set(guild.id, this.cacheInvites(newInvites));
      }
    });
    
    this.client.on('inviteCreate', async (invite) => {
      if (invite.guild) {
        await this.refreshInviteCacheForGuild(invite.guild.id);
      }
    });
    
    this.client.on('inviteDelete', async (invite) => {
      if (invite.guild) {
        await this.refreshInviteCacheForGuild(invite.guild.id);
      }
    });
  }

  private cacheInvites(invites: Collection<string, any>): Collection<string, CachedInvite> {
    const cache = new Collection<string, CachedInvite>();
    invites.forEach(inv => {
      cache.set(inv.code, {
        code: inv.code,
        uses: inv.uses || 0,
        inviterId: inv.inviter?.id || null
      });
    });
    return cache;
  }
  
  private async refreshInviteCacheForGuild(guildId: string) {
    try {
      const guild = await this.client.guilds.fetch(guildId);
      const invites = await guild.invites.fetch();
      this.inviteCache.set(guildId, this.cacheInvites(invites));
    } catch (e) {
      console.error(`Failed to refresh invites for guild ${guildId}:`, e);
    }
  }

  public async refreshInviteCache() {
    console.log("Refreshing invite cache...");
    for (const [id, guild] of this.client.guilds.cache) {
      await this.refreshInviteCacheForGuild(id);
    }
    return true;
  }

  public async generateLeaderboard() {
    const trackedChannelId = await storage.getSetting(SETTINGS_KEYS.TRACKED_CHANNEL_ID);
    if (!trackedChannelId) throw new Error("Tracked channel not set");

    const channel = await this.client.channels.fetch(trackedChannelId);
    if (!channel || !(channel instanceof TextChannel)) {
      throw new Error("Invalid tracked channel");
    }

    const moderators = await storage.getModerators();
    // Filter out ignored and sort by message count
    const ranked = moderators
      .filter(m => !m.isIgnored)
      .sort((a, b) => b.messageCount - a.messageCount);

    const embed = new EmbedBuilder()
      .setTitle("🏆 Weekly Moderator Leaderboard")
      .setColor(0xFFD700)
      .setTimestamp();

    const top3 = ranked.slice(0, 3);
    const rewards = [40, 30, 20]; // 1st, 2nd, 3rd

    let description = "";

    // Award points and build description
    for (let i = 0; i < top3.length; i++) {
      const mod = top3[i];
      const reward = rewards[i];
      
      // Update leaderboard points
      await storage.updateModerator(mod.id, {
        leaderboardPoints: mod.leaderboardPoints + reward
      });

      const totalPoints = 
        Math.floor(mod.messageCount / 1000) * 15 + 
        mod.inviteCount + 
        mod.manualPoints + 
        mod.leaderboardPoints + reward; // Include the new reward in display? Yes.

      description += `**#${i + 1}** <@${mod.discordId}> - ${mod.messageCount} msgs (+${reward} pts)\n`;
    }

    // List rest
    for (let i = 3; i < ranked.length; i++) {
      const mod = ranked[i];
      description += `**#${i + 1}** <@${mod.discordId}> - ${mod.messageCount} msgs\n`;
    }

    if (!description) description = "No active moderators tracked yet.";

    embed.setDescription(description);
    await channel.send({ embeds: [embed] });
    return true;
  }

  public async start(token: string) {
    try {
      await this.client.login(token);
    } catch (e) {
      console.error("Failed to login to Discord:", e);
    }
  }
}

export const bot = new DiscordBot();
